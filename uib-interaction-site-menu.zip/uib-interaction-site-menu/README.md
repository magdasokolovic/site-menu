# Site menu

Take a look at the example and try to recreate the effect.

![example](site-menu-example.png)

![example hover](site-menu-hover-2-example.png)

![example](site-menu-example.gif)

> Use transitions